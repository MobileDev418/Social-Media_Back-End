<?php

require_once("./function.php");
check_user();
include ("header.php");
?>
<body class="page-header-fixed page-sidebar-closed-hide-logo page-sidebar-closed-hide-logo">

<?php
include ("top-navigation.php");
?>
<div class="clearfix">
</div>
<!-- BEGIN CONTAINER -->
<div class="page-container">
	<div class="page-sidebar-wrapper">
        <?php require_once("left-navigation.php"); ?>
	</div>
	<div class="page-content-wrapper">
<!--        donjin-->
        <?php
        $datas = adminGetUsers();
        ?>
        <div id="main" class="page-content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-sm-12">
                        <div class="box box-color box-bordered"  style="min-width: 1200px;">
                            <div class="box-title">
                                <h3>
                                    <i class="fa fa-table"></i>
                                    Manage User
                                </h3>
                            </div>
                            <div class="box-content nopadding">
                                <table class="table table-hover table-nomargin dataTable table-bordered">
                                    <thead>
                                    <tr>
                                        <th>Photo</th>
                                        <th>Full name</th>
                                        <th>User name</th>
                                        <th>Email</th>
                                        <th>Permission</th>
                                        <th>Action</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                        foreach($datas as $data){
                                            extract($data);
                                            echo "<tr>";
                                            echo "<td> <img src='".SAVE_USER_PHOTO.$photo."' style='width:70px;height:70px;'> </td>";
                                            echo "<td> ".$fullname." </td>";
                                            echo "<td> $username </td>";
                                            echo "<td> $email </td>";
                                            echo "<td> $permission[$is_admin] </td>";
                                            echo '<td> <a href="./admin_editUser.php?key=edit&uid='.$id.'" class="btn" rel="tooltip" title="Edit"><i class="fa fa-edit"></i></a>
												<a href="./action.php?key=delUser&uid='.$id.'" class="btn" rel="tooltip" title="Delete"><i class="fa fa-times"></i>
												</a> </td>';
                                            echo "</tr>";
                                        }
                                        ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
<!--donjin end-->
	</div>
	<!-- END CONTENT -->
</div>
<!-- END CONTAINER -->
<!-- BEGIN FOOTER -->
<div class="page-footer">
	<div class="page-footer-inner">
		 2015 &copy; Indyhost.net Develop Team.
	</div>
	<div class="scroll-to-top">
		<i class="icon-arrow-up"></i>
	</div>
</div>
<!-- END FOOTER -->
<!-- BEGIN CORE PLUGINS -->
<script src="../assets/global/scripts/metronic.js" type="text/javascript"></script>
<script src="../assets/admin/layout4/scripts/layout.js" type="text/javascript"></script>
<script src="../assets/admin/layout4/scripts/demo.js" type="text/javascript"></script>
<!--<script src="../assets/admin/pages/scripts/table-advanced.js"></script>-->
<script src="../assets/admin/pages/scripts/index3.js" type="text/javascript"></script>
<script src="../assets/admin/pages/scripts/tasks.js" type="text/javascript"></script>
<script>

    jQuery(document).ready(function() {
        Metronic.init(); // init metronic core components
        Layout.init(); // init current layout
        Demo.init(); // init demo features
//        TableAdvanced.init();
    });
</script>
</body>
<!-- END BODY -->
</html>