<?php
error_reporting(1);
    header('Content-Type: text/html; charset=utf-8');
    require_once("../api/Database.php");
    define('SAVE_PHOTO', './images/photos/');  // save image path
    define('DELETE_PHOTO', './images/photos/');  // delete image path
    $db = new Database();


    include_once("./simple_html_dom.php");

$base_url = "http://espn.go.com";
$param = $_REQUEST;

$response = array();
if(!isset($param['key'])){
    redirect_url("./index.php");
}
elseif($param['key'] == "get_event"){
    if($param['subject'] == "basketball"){
        extract($param);
        $response = get_event( $gameId, $subject, $id, $club, $key1 );
        echo json_encode($response);
        exit;
    }

}elseif($param['key'] == "get_schedule"){
    switch($param['subject']){
        case "basketball":
            // http://espn.go.com/mens-college-basketball/team/schedule/_/id/399/albany-great-danes
            $url = "http://espn.go.com/mens-college-basketball/team/schedule/_/id/".$param['key2']."/".$param['key1'];
            $response = get_schedule_college($url, $param['subject'],$param['club'],$param['key2']);
            echo json_encode($response);
            exit;
            break;
        case "football":
            // http://espn.go.com/college-football/team/schedule/_/id/2132/cincinnati-bearcats
            $url = "http://espn.go.com/college-football/team/schedule/_/id/".$param['key2']."/".$param['key1'];
            $response = get_schedule_college($url, $param['subject'],$param['club'],$param['key2']);
            echo json_encode($response);
            exit;
            break;
        case "mlb":
            // http://espn.go.com/mlb/team/schedule/_/name/bal/baltimore-orioles
            $url = "http://espn.go.com/mlb/team/schedule/_/name/".$param['key2']."/".$param['key1'];
            $response = get_schedule_pro($url, $param['subject'],$param['club'],$param['key2']);
            echo json_encode($response);
            exit;
            break;
        case "nfl":
            // http://espn.go.com/nfl/team/schedule/_/name/dal/dallas-cowboys
            $url = "http://espn.go.com/nfl/team/schedule/_/name/".$param['key2']."/".$param['key1'];
            $response = get_schedule_pro($url, $param['subject'],$param['club'],$param['key2']);
            echo json_encode($response);
            exit;
            break;
        case "nba":
            // http://espn.go.com/nba/team/schedule/_/name/bos/boston-celtics
            $url = "http://espn.go.com/nba/team/schedule/_/name/".$param['key2']."/".$param['key1'];
            $response = get_schedule_pro($url, $param['subject'],$param['club'],$param['key2']);
            echo json_encode($response);
            exit;
            break;
        case "nhl":
            // http://espn.go.com/nhl/team/schedule/_/name/chi/chicago-blackhawks
            $url = "http://espn.go.com/nhl/team/schedule/_/name/".$param['key2']."/".$param['key1'];
            $response = get_schedule_pro($url, $param['subject'],$param['club'],$param['key2']);
            echo json_encode($response);
            exit;
            break;
        case "mls":
            // http://www.espnfc.com/club/chicago-fire/182/fixtures
            $url = "http://www.espnfc.com/club/".$param['key1']."/".$param['key2']."/fixtures";
            $response = get_schedule_pro($url, $param['subject'],$param['club'],$param['key2']);
            echo json_encode($response);
            exit;
            break;
        default :
            break;
    }
}elseif($param['target'] == "team"){
    //print_r($param);exit;
    switch($param['key']){
        case "basketball":
            $url = "http://espn.go.com/mens-college-basketball/teams";
            $response = get_teams($url, "basketball");
            update_db("basketball",$response);
            echo json_encode($response);
            exit;
            break;
        case "football":
            $url = "http://espn.go.com/college-football/teams";
            $response = get_teams($url, "football");
            update_db("football",$response);
            echo json_encode($response);
            exit;
            break;
        case "MLB":
            $url = "http://espn.go.com/mlb/teams";
            $response = get_proTeams($url, "mlb");
            update_db("mlb",$response);
            echo json_encode($response);
            exit;
            break;
        case "NFL":
            $url = "http://espn.go.com/nfl/teams";
            $response = get_proTeams($url, "nfl");
            update_db("nfl",$response);
            echo json_encode($response);
            exit;
            break;
        case "NBA":
            $url = "http://espn.go.com/nba/teams";
            $response = get_proTeams($url, "nba");
            update_db("nba",$response);
            echo json_encode($response);
            exit;
            break;
        case "NHL":
            $url = "http://espn.go.com/nhl/teams";
            $response = get_proTeams($url, "nhl");
            update_db("nhl",$response);
            echo json_encode($response);
            exit;
            break;
        case "MLS":
            $url = "http://www.espnfc.com/major-league-soccer/19/index";
            $response = get_proTeams($url, "mls");
            update_db("mls",$response);
            echo json_encode($response);
            exit;
            break;
        default :
            break;
    }
    exit;
}

/* event */
function get_event($gameId, $subject, $id, $club, $key1){
    global $base_url, $db;
    $result = array();
    if($subject == "basketball"){
        // http://espn.go.com/ncb/conversation?gameId=400809380
        $url = $base_url."/ncb/conversation?gameId=".$gameId;
        $html = file_get_html($url);
        $result = array();
        // //*[@id="gamepackageTop"]/div[4]/div/p[2]
        $address = "";
        foreach($html->find('//*[@id="gamepackageTop"]/div[4]/div/p[2]') as $element){
            $address = $db->_db->real_escape_string($element->innertext);
        }
        $home_team = "";
        $teamID = "";
        foreach($html->find('//*[@id="matchup-ncb-'.$gameId.'"]/div[2]/div[2]/h3/a') as $element){
            $url = $element->getAttribute('href');
            preg_match_all('/http:\/\/espn.go.com\/.*?\/team\/_\/id\/(?P<teamId>.*?)\/.*?/s', $url, $arr);
            $team = $arr['teamId'];
            $teamID = $team[0];
            $home_team = str_replace("http://espn.go.com/mens-college-basketball/team/_/id/".$teamID."/","",$url);
            $home_team = str_replace("'","",$home_team);
        }
        $sql = "INSERT INTO _temp_basketball_address(gameId, address, home_team, team_id) VALUES";
        $sql .= "('".$gameId."', '".$address."', '".$home_team."', '".$teamID."');";
        $db -> execute($sql);

        $result = array("gameId"=> $gameId, "address"=> $address, "home_team"=>$home_team, "team_id"=> $teamID);
    }


    return $result;
}


/* schedule */
function get_schedule_college($url, $subject, $club, $key2){
    global $base_url, $db;
    $html = file_get_html($url);
    $result = array();
    /* get event module */
    foreach($html->find('//*[@id="showschedule"]/div/table/tbody/tr') as $element){
        $chk = $element->getAttribute("class");
        if ((strpos($chk,'oddrow') !== false) || (strpos($chk,'evenrow') !== false)) {
            $chk = str_replace("oddrow","",$chk);
            $chk = str_replace("evenrow","",$chk);
            $chk = str_replace(" ","",$chk);
            $chk = str_replace("team-","",$chk);
            $vs_ck = explode("-",$chk);

            $part1 = $element->find('td[1]');
            $time = $part1[0]->innertext;
            $date =  date_create_from_format("D, M d", $time);
            $date = date_format( $date, "Y/m/d");
            $start = strtotime($date) + 12*3600;
            $end = strtotime($date) + 23*3600;

            $part2 = $element->find('td[2]/ul/li[3]/a');
            $opponent = $db->_db->real_escape_string($part2[0]->innertext);

            $part3 = $element->find('td[2]/ul/li[1]');
            $game_status = $part3[0]->innertext;
            $home_team = "";
            $home_team_id = "";
            $away_team = "";
            $away_team_id = "";
            if($game_status == "@"){
                $home_team = $opponent;
                $home_team_id = $vs_ck[1];
                $away_team = $club;
                $away_team_id = $key2;
            }elseif($game_status == "vs"){
                $home_team = $club;
                $home_team_id = $key2;
                $away_team = $opponent;
                $away_team_id = $vs_ck[1];
            }

            $is_save = 0;
            if($home_team_id != "" && $away_team_id != "" && $subject != ""){
                $is_save = save_pre_event($subject, $start, $end,$home_team, $home_team_id, $away_team, $away_team_id);
            }

            $result[] = array("subject"=>$subject, "start" => $start, "end"=>$end, "home_team"=>$home_team,
                            "home_team_id"=>$home_team_id, "away_team"=>$away_team, "away_team_id"=>$away_team_id, "is_save"=>$is_save);
        }
    }

    return $result;
}
function get_schedule_pro($url, $subject, $club, $key2){
    global $base_url, $db;
    $html = file_get_html($url);
    $result = array();
    if($subject == "mlb"){
        /* get MLB schedule  */
        foreach($html->find('//*[@id="my-teams-table"]/div/div/table/tbody/tr') as $element){
            $chk = $element->getAttribute("class");
            if ((strpos($chk,'oddrow') !== false) || (strpos($chk,'evenrow') !== false)) {

                $part1 = $element->find('td[1]');
                $time = str_replace("<nobr>", "", $part1[0]->innertext);
                $date =  date_create_from_format("D, M d", $time);
                $date = date_format( $date, "Y/m/d");
                $start = strtotime($date) + 12*3600;
                $end = strtotime($date) + 23*3600;
                $now = time();

                if($now <  $start){
                    $part2 = $element->find('td[2]/ul/li[3]/a');
                    $opponent = $db->_db->real_escape_string($part2[0]->innertext);
                    // http://espn.go.com/mlb/team/schedule/_/name/bal/baltimore-orioles
                    $url1 = str_replace("http://espn.go.com/","",$part2[0]->getAttribute("href"));
                    preg_match_all('/.*?\/team\/_\/name\/(?P<teamId>.*?)\/.*?/s', $url1, $arr);
                    $team_id = $arr['teamId'][0];


                    $part3 = $element->find('td[2]/ul/li[1]');
                    $game_status = $part3[0]->innertext;
                    $home_team = "";
                    $home_team_id = "";
                    $away_team = "";
                    $away_team_id = "";
                    if($game_status == "@"){
                        $home_team = $opponent;
                        $home_team_id = $team_id;
                        $away_team = $club;
                        $away_team_id = $key2;
                    }elseif($game_status == "vs"){
                        $home_team = $club;
                        $home_team_id = $key2;
                        $away_team = $opponent;
                        $away_team_id = $team_id;
                    }

                    /* get real time */
                    //*[@id="my-teams-table"]/div/div/table/tbody/tr[35]/td[3]
                    $p_time = $element->find('td[3]');
                    // 7:05 PM
                    $play_time = $p_time[0]->innertext;
                    $is_save = "";
                    $game_time = "";
                    if($play_time == ''){
                        $game_time = "TBD";
                        $is_save = $game_time;
                    }else{
                        $arr_time = explode(" ",$play_time);
                        $time_h_m = $arr_time[0];
                        if(strtoupper($arr_time[1]) == "PM"){
                            $g_t_string = explode(":", $time_h_m);
                            $g_t_h = $g_t_string[0];
                            $g_t_m = $g_t_string[1];
                            $game_time = strtotime($date) + ($g_t_h + 12)*3600+$g_t_m * 60;
                            $is_save = date('m d Y h:i A',$game_time);
                        }else{
                            $g_t_string = explode(":", $time_h_m);
                            $g_t_h = $g_t_string[0];
                            $g_t_m = $g_t_string[1];
                            $game_time = strtotime($date) + $g_t_h*3600+$g_t_m * 60;
                            $is_save = date('m d Y h:i A',$game_time);
                        }

                    }
                    if($home_team_id != "" && $away_team_id != "" && $subject != ""){
                        save_pre_event($subject, $start, $end,$home_team, $home_team_id, $away_team, $away_team_id, $game_time);
                    }

                    $result[] = array("subject"=>$subject, "start" => $start, "end"=>$end, "home_team"=>$home_team,
                        "home_team_id"=>$home_team_id, "away_team"=>$away_team, "away_team_id"=>$away_team_id, "is_save"=>$is_save);
                }
            }
        }
    }elseif($subject == "nfl"){
        /* get NFL schedule  */
        foreach($html->find('//*[@id="my-teams-table"]/div/div/table/tbody/tr') as $element){
            $chk = $element->getAttribute("class");
            if ((strpos($chk,'oddrow') !== false) || (strpos($chk,'evenrow') !== false)) {

                $part1 = $element->find('td[2]');
                $time = str_replace("<nobr>", "", $part1[0]->innertext);
                $date =  date_create_from_format("D, M d", $time);
                $date = date_format( $date, "Y/m/d");
                $start = strtotime($date) + 12*3600;
                $end = strtotime($date) + 23*3600;
                $now = time();

                if($now <  $start){
                    $part2 = $element->find('td[3]/ul/li[3]/a');
                    $opponent = $db->_db->real_escape_string($part2[0]->innertext);
                    // http://espn.go.com/mlb/team/schedule/_/name/bal/baltimore-orioles
                    $url1 = str_replace("http://espn.go.com/","",$part2[0]->getAttribute("href"));
                    preg_match_all('/.*?\/team\/_\/name\/(?P<teamId>.*?)\/.*?/s', $url1, $arr);
                    $team_id = $arr['teamId'][0];


                    $part3 = $element->find('td[3]/ul/li[1]');
                    $game_status = $part3[0]->innertext;
                    $home_team = "";
                    $home_team_id = "";
                    $away_team = "";
                    $away_team_id = "";
                    if($game_status == "@"){
                        $home_team = $opponent;
                        $home_team_id = $team_id;
                        $away_team = $club;
                        $away_team_id = $key2;
                    }elseif($game_status == "vs"){
                        $home_team = $club;
                        $home_team_id = $key2;
                        $away_team = $opponent;
                        $away_team_id = $team_id;
                    }

                    /* get real time */
                    //*[@id="my-teams-table"]/div[4]/div/table/tbody/tr[10]/td[4]
                    $p_time = $element->find('td[4]');
                    // 7:05 PM
                    $play_time = $p_time[0]->innertext;
                    $is_save = "";
                    $game_time = "";
                    if($play_time == ''){
                        $game_time = "TBD";
                        $is_save = $game_time;
                    }else{
                        $arr_time = explode(" ",$play_time);
                        $time_h_m = $arr_time[0];
                        if(strtoupper($arr_time[1]) == "PM"){
                            $g_t_string = explode(":", $time_h_m);
                            $g_t_h = $g_t_string[0];
                            $g_t_m = $g_t_string[1];
                            $game_time = strtotime($date) + ($g_t_h + 12)*3600+$g_t_m * 60;
                            $is_save = date('m d Y h:i A',$game_time);
                        }else{
                            $g_t_string = explode(":", $time_h_m);
                            $g_t_h = $g_t_string[0];
                            $g_t_m = $g_t_string[1];
                            $game_time = strtotime($date) + $g_t_h*3600+$g_t_m * 60;
                            $is_save = date('m d Y h:i A',$game_time);
                        }

                    }
                    if($home_team_id != "" && $away_team_id != "" && $subject != ""){
                        save_pre_event($subject, $start, $end,$home_team, $home_team_id, $away_team, $away_team_id, $game_time);
                    }

                    $result[] = array("subject"=>$subject, "start" => $start, "end"=>$end, "home_team"=>$home_team,
                        "home_team_id"=>$home_team_id, "away_team"=>$away_team, "away_team_id"=>$away_team_id, "is_save"=>$is_save);
                }
            }
        }
    }elseif($subject == "nba"){
        /* get NBA schedule  */
        foreach($html->find('//*[@id="my-teams-table"]/div/div/table/tbody/tr') as $element){
            $chk = $element->getAttribute("class");
            if ((strpos($chk,'oddrow') !== false) || (strpos($chk,'evenrow') !== false)) {

                $part1 = $element->find('td[1]');
                $time = str_replace("<nobr>", "", $part1[0]->innertext);
                $date =  date_create_from_format("D, M d", $time);
                $date = date_format( $date, "Y/m/d");
                $start = strtotime($date) + 12*3600;
                $end = strtotime($date) + 23*3600;
                $now = time();

                if($now <  $start){
                    $part2 = $element->find('td[2]/ul/li[3]/a');
                    $opponent = $db->_db->real_escape_string($part2[0]->innertext);
                    // http://espn.go.com/mlb/team/schedule/_/name/bal/baltimore-orioles
                    $url1 = str_replace("http://espn.go.com/","",$part2[0]->getAttribute("href"));
                    preg_match_all('/.*?\/team\/_\/name\/(?P<teamId>.*?)\/.*?/s', $url1, $arr);
                    $team_id = $arr['teamId'][0];


                    $part3 = $element->find('td[2]/ul/li[1]');
                    $game_status = $part3[0]->innertext;
                    $home_team = "";
                    $home_team_id = "";
                    $away_team = "";
                    $away_team_id = "";
                    if($game_status == "@"){
                        $home_team = $opponent;
                        $home_team_id = $team_id;
                        $away_team = $club;
                        $away_team_id = $key2;
                    }elseif($game_status == "vs"){
                        $home_team = $club;
                        $home_team_id = $key2;
                        $away_team = $opponent;
                        $away_team_id = $team_id;
                    }

                    /* get real time */
                    //*[@id="my-teams-table"]/div/div/table/tbody/tr[35]/td[3]
                    $p_time = $element->find('td[3]');
                    // 7:05 PM
                    $play_time = $p_time[0]->innertext;
                    $is_save = "";
                    $game_time = "";
                    if($play_time == ''){
                        $game_time = "TBD";
                        $is_save = $game_time;
                    }else{
                        $arr_time = explode(" ",$play_time);
                        $time_h_m = $arr_time[0];
                        if(strtoupper($arr_time[1]) == "PM"){
                            $g_t_string = explode(":", $time_h_m);
                            $g_t_h = $g_t_string[0];
                            $g_t_m = $g_t_string[1];
                            $game_time = strtotime($date) + ($g_t_h + 12)*3600+$g_t_m * 60;
                            $is_save = date('m d Y h:i A',$game_time);
                        }else{
                            $g_t_string = explode(":", $time_h_m);
                            $g_t_h = $g_t_string[0];
                            $g_t_m = $g_t_string[1];
                            $game_time = strtotime($date) + $g_t_h*3600+$g_t_m * 60;
                            $is_save = date('m d Y h:i A',$game_time);
                        }

                    }
                    if($home_team_id != "" && $away_team_id != "" && $subject != ""){
                        save_pre_event($subject, $start, $end,$home_team, $home_team_id, $away_team, $away_team_id, $game_time);
                    }

                    $result[] = array("subject"=>$subject, "start" => $start, "end"=>$end, "home_team"=>$home_team,
                        "home_team_id"=>$home_team_id, "away_team"=>$away_team, "away_team_id"=>$away_team_id, "is_save"=>$is_save);
                }
            }
        }
    }elseif($subject == "nhl"){
        /* get NHL schedule  */
        foreach($html->find('//*[@id="my-teams-table"]/div/div/table/tbody/tr') as $element){
            $chk = $element->getAttribute("class");
            if ((strpos($chk,'oddrow') !== false) || (strpos($chk,'evenrow') !== false)) {

                $part1 = $element->find('td[1]');
                $time = str_replace("<nobr>", "", $part1[0]->innertext);
                $date =  date_create_from_format("D, M d", $time);
                $date = date_format( $date, "Y/m/d");
                $start = strtotime($date) + 12*3600;
                $end = strtotime($date) + 23*3600;
                $now = time();

                if($now <  $start){
                    $part2 = $element->find('td[2]/ul/li[3]/a');
                    $opponent = $db->_db->real_escape_string($part2[0]->innertext);
                    // http://espn.go.com/mlb/team/schedule/_/name/bal/baltimore-orioles
                    $url1 = str_replace("http://espn.go.com/","",$part2[0]->getAttribute("href"));
                    preg_match_all('/.*?\/team\/_\/name\/(?P<teamId>.*?)\/.*?/s', $url1, $arr);
                    $team_id = $arr['teamId'][0];


                    $part3 = $element->find('td[2]/ul/li[1]');
                    $game_status = $part3[0]->innertext;
                    $home_team = "";
                    $home_team_id = "";
                    $away_team = "";
                    $away_team_id = "";
                    if($game_status == "@"){
                        $home_team = $opponent;
                        $home_team_id = $team_id;
                        $away_team = $club;
                        $away_team_id = $key2;
                    }elseif($game_status == "vs"){
                        $home_team = $club;
                        $home_team_id = $key2;
                        $away_team = $opponent;
                        $away_team_id = $team_id;
                    }

                    /* get real time */
                    //*[@id="my-teams-table"]/div/div/table/tbody/tr[35]/td[3]
                    $p_time = $element->find('td[3]');
                    // 7:05 PM
                    $play_time = $p_time[0]->innertext;
                    $is_save = "";
                    $game_time = "";
                    if($play_time == ''){
                        $game_time = "TBD";
                        $is_save = $game_time;
                    }else{
                        $arr_time = explode(" ",$play_time);
                        $time_h_m = $arr_time[0];
                        if(strtoupper($arr_time[1]) == "PM"){
                            $g_t_string = explode(":", $time_h_m);
                            $g_t_h = $g_t_string[0];
                            $g_t_m = $g_t_string[1];
                            $game_time = strtotime($date) + ($g_t_h + 12)*3600+$g_t_m * 60;
                            $is_save = date('m d Y h:i A',$game_time);
                        }else{
                            $g_t_string = explode(":", $time_h_m);
                            $g_t_h = $g_t_string[0];
                            $g_t_m = $g_t_string[1];
                            $game_time = strtotime($date) + $g_t_h*3600+$g_t_m * 60;
                            $is_save = date('m d Y h:i A',$game_time);
                        }

                    }
                    if($home_team_id != "" && $away_team_id != "" && $subject != ""){
//                        $ho = $db->single("SELECT key2 FROM venues WHERE club = '$home_team' AND SUBJECT = 'mls'");
//                        $home_team_id = $ho['key2'];
//                        $aw = $db->single("SELECT key2 FROM venues WHERE club = '$away_team' AND SUBJECT = 'mls'");
//                        $away_team_id = $aw['key2'];
                        save_pre_event($subject, $start, $end,$home_team, $home_team_id, $away_team, $away_team_id, $game_time);
                    }

                    $result[] = array("subject"=>$subject, "start" => $start, "end"=>$end, "home_team"=>$home_team,
                        "home_team_id"=>$home_team_id, "away_team"=>$away_team, "away_team_id"=>$away_team_id, "is_save"=>$is_save);
                }
            }
        }
    }elseif($subject == "mls"){
            /* get NHL schedule  */
        $result = array();
        foreach($html->find('//*[@id="club-fixtures"]/div[5]/a') as $element){
            // 412261
            $game_id = $element->getAttribute("data-gameid");
            $is_upcoming = $element->getAttribute("class");
            $is_upcoming = str_replace(" ","", $is_upcoming);
            $is_upcoming = str_replace("score-list","", $is_upcoming);
            if($is_upcoming == "upcoming"){
                // this is upcoming event
                // get home team id div[2]/div/div[1]/img
                $h_t_alt = $element->find('div[2]/div/div[1]/img');
                $h_t_name = $h_t_alt[0]->getAttribute('alt');
                // get away team id div[4]/div/div[1]/img
                $a_t_alt = $element->find('div[4]/div/div[1]/img');
                $a_t_name = $a_t_alt[0]->getAttribute('alt');

                $part1 = $element->find('div[1]/div/div[2]'); // Aug 23, 2015
                $time = $part1[0]->innertext;
                $date =  date_create_from_format("M d, Y", $time);
                $date = date_format( $date, "Y/m/d");
                $start = strtotime($date) + 9*3600;
                $end = strtotime($date) + 24*3600 - 1;

                // get time //*[@id="club-fixtures"]/div[5]/a[43]/div[6]/div/div[1]
                $p_time = $element->find('div[6]/div/div[1]');
                // 2015-10-05T01:30:00.000+0000
                $play_time = $p_time[0]->getAttribute('data-time');
                $is_save = "";
                $game_time = "";
                if($play_time == 'null'){
                    $game_time = "TBD";
                    $is_save = $game_time;
                }else{
                    $play_time = str_replace("T"," ",$play_time);
                    $play_time = str_replace(":00.000+0000","",$play_time);
                    $g_t_string = substr($play_time, -5);
                    $g_t_h =substr($g_t_string,0, 2);
                    $g_t_m =substr($g_t_string,3, 2);
                    $game_time = strtotime($date) + $g_t_h*3600+$g_t_m * 60;
                    $is_save = date('m d Y h:i A',$game_time);
                }
                $home_team = $h_t_name;
                $home_team_id = "";
                $away_team = $a_t_name;
                $away_team_id = "";


                if($home_team != "" && $away_team != "" && $subject != ""){
                    $ho = $db->single("SELECT key2 FROM venues WHERE club = '$home_team' AND SUBJECT = 'mls'");
                    $home_team_id = $ho['key2'];
                    $aw = $db->single("SELECT key2 FROM venues WHERE club = '$away_team' AND SUBJECT = 'mls'");
                    $away_team_id = $aw['key2'];
                    save_pre_event($subject, $start, $end,$home_team, $home_team_id, $away_team, $away_team_id, $game_time);
                }

                $result[] = array("subject"=>$subject, "start" => $start, "end"=>$end, "home_team"=>$home_team,
                    "home_team_id"=>$home_team_id, "away_team"=>$away_team, "away_team_id"=>$away_team_id, "is_save"=>$is_save);
            }
        }
    }
    return $result;
}

function get_teams($url, $category){
//    $url = "http://espn.go.com/mens-college-basketball/team/_/id/399/albany-great-danes";
//    preg_match_all('/http:\/\/espn.go.com\/.*?\/team\/_\/id\/(?P<teamId>.*?)\/.*?/s', $url, $arr);
//    $teamID = $arr['teamId'];
//    print_r($teamID[0]);exit;

    global $base_url, $db;
    $html = file_get_html($url);
    $result = array();
    foreach($html->find('//*[@id="content"]/div[3]/div[1]/div/div/div/div/ul/li/h5/a') as $element){
        $url = str_replace("http://espn.go.com/","",$element->getAttribute("href"));
        preg_match_all('/.*?\/team\/_\/id\/(?P<teamId>.*?)\/.*?/s', $url, $arr);
        $key2 = $arr['teamId'][0];
        // http://espn.go.com/mens-college-basketball/team/_/id/399/albany-great-danes
        // http://espn.go.com/college-football/team/_/id/2132/cincinnati-bearcats
        $key1 = "";
        if($category == "basketball"){
            $key1 = str_replace("mens-college-basketball/team/_/id/".$key2."/","",$url);
        }
        elseif($category == "football"){
            $key1 = str_replace("college-football/team/_/id/".$key2."/","",$url);
        }
        $team_name = $db->_db->real_escape_string($element->innertext);
        $result[] = array("name"=>$team_name, "key1" => $key1, "key2"=>$key2, "url"=>$url);
    }

    return $result;
}
function get_proTeams($url, $category){
    global $base_url, $db;
    $html = file_get_html($url);
    $result = array();
    if($category = 'mls'){
        foreach($html->find('//*[@id="submenu-content-items"]/ul/li[4]/ul/li/a') as $element){
            // http://www.espnfc.com/club/chicago-fire/182/index
            $url = str_replace("http://www.espnfc.com/","",$element->getAttribute("href"));
            preg_match_all('/club\/(?P<teamKey>.*?)\/(?P<teamId>.*?)\/index/s', $url, $arr);
            $key2 = $arr['teamId'][0];
            $key1 = $arr['teamKey'][0];

            $team_name = $db->_db->real_escape_string($element->innertext);
            $result[] = array("name"=>$team_name, "key1" => $key1, "key2"=>$key2, "url" => $url);
        }
    }else{
        foreach($html->find('//*[@id="content"]/div[3]/div[1]/div/div/div/div/ul/li/div/h5/a') as $element){
            $url = str_replace("http://espn.go.com/","",$element->getAttribute("href"));
            preg_match_all('/.*?\/team\/_\/name\/(?P<teamId>.*?)\/.*?/s', $url, $arr);
            $key2 = $arr['teamId'][0];
            // http://espn.go.com/mlb/team/_/name/chw/chicago-white-sox
            $key1 = str_replace($category."/team/_/name/".$key2."/","",$url);
            $team_name = $db->_db->real_escape_string($element->innertext);
            $result[] = array("name"=>$team_name, "key1" => $key1, "key2"=>$key2, "url" => $url);
        }
    }


    return $result;
}
function update_db($table, $result){
    global $db;
    $table_name = "team_".$table;
    $sql = "";
    foreach($result as $row){
        $name = str_replace("'","",$row['name']);
        $key1 = str_replace("'","",$row['key1']);
        $key2 = str_replace("'","",$row['key2']);
        $sql = "INSERT INTO ".$table_name."(team_name, key1, key2) VALUES";
        $sql .= "('".$name."', '".$key1."', '".$key2."');";
        $db -> execute($sql);
    }
}
function save_pre_event($subject, $start, $end, $home_team, $home_team_id, $away_team, $away_team_id, $game_time){
    global $db;
    $is_save = false;
    $chk = $db->single("SELECT COUNT(*) as ct FROM pre_events WHERE subject = '$subject' AND home_team_id = '$home_team_id' AND away_team_id='$away_team_id' and event_start = '$start' ");
    $result_venue_id = $db->single("select id from venues where subject = '$subject' and key2 = '$home_team_id'");
    $venue_id = $result_venue_id['id'];
    if($chk['ct'] == 1){
        $sql = "update pre_events set venue_id = '$venue_id',real_time='$game_time', event_start='$start', event_end='$end',home_team='$home_team',away_team='$away_team' WHERE subject = '$subject' AND home_team_id = '$home_team_id' AND away_team_id='$away_team_id' and event_start = '$start' ";
    }else{
        $sql = "INSERT INTO pre_events(subject, real_time, event_start, event_end, home_team, home_team_id, away_team, away_team_id, venue_id) VALUES";
        $sql .= "('".$subject."', '".$game_time."', '".$start."', '".$end."', '".$home_team."', '".$home_team_id."', '".$away_team."', '".$away_team_id."', '$venue_id');";
    }

    if($db -> execute($sql)){
        $is_save = 1;
    }else{
        $is_save = 0;
    }
    return $is_save;
}

?>