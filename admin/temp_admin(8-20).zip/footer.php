<div class="footer">
    <div class="pull-right">

    </div>
    <div>
        <strong>Copyright</strong> VanityDating App Admin &copy; 2015.7
    </div>
</div>