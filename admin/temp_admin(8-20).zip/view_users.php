<?php
include ("./header.php");
?>
<body>

<div id="wrapper">
<?php require_once("./left_navigation.php"); ?>

    <div id="page-wrapper" class="gray-bg">
<?php require_once("./top_navigation.php") ?>
    <div class="row wrapper border-bottom white-bg page-heading">
        <div class="col-lg-10">
            <h2 style="font-weight: bold">Users</h2>
        </div>
    </div>
    <div class="wrapper wrapper-content animated fadeInRight">
        <div class="row">
            <div class="col-lg-12">
                <div class="ibox float-e-margins">
                    <div class="ibox-content">
                        <?php $datas = adminGetUsers(); ?>
                        <table class="table table-striped table-bordered table-hover " id="editable" >
                            <thead>
                                <tr>
                                    <th>Avatar</th>
                                    <th>User name</th>
                                    <th>Email</th>
                                    <th>Gender</th>
                                    <th>Birthday</th>
                                    <th>Interested In</th>
                                    <th>Deactivate</th>
                                    <th>Created</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                            <?php
                                foreach($datas as $user){
                                    extract($user);
                                    echo '<tr class="gradeU">';
                                    echo '<th><a href="./editUser.php?key=edit&uid='.$id.'">
                                            <img src="../images/photo/'.$photo_url.'" style="width:35px;height:35px;border-radius: 50%;">
                                            </a></th>';
                                    echo "<th>$username</th>";
                                    echo "<th>$email</th>";
                                    echo "<th>$GENDER[$gender]</th>";
                                    echo "<th>$birthday</th>";
                                    echo "<th>$GENDER[$interested_in]</th>";
                                    if($status == 1){
                                        echo "<th></th>";
                                    }elseif($status == 0){
                                        echo '<th><a href="./action.php?key=susUser&uid='.$id.'" class="btn" rel="tooltip" title="Activate"><i class="fa fa-undo"></i></a></th>';
                                    }
                                    echo "<th>".date('M d, Y',$created)."</th>";
                                    echo '<th>
                                                <a href="./editUser.php?key=edit&uid='.$id.'" class="btn" rel="tooltip" title="Edit"><i class="fa fa-edit"></i></a>
                                                <a href="./action.php?key=delUser&uid='.$id.'" class="btn" rel="tooltip" title="Delete"><i class="fa fa-trash-o"></i></a>
                                            </th>';
                                }
                            ?>
                            </tbody>
                            <tfoot>
                                <tr>
                                    <th>Avatar</th>
                                    <th>User name</th>
                                    <th>Email</th>
                                    <th>Gender</th>
                                    <th>Birthday</th>
                                    <th>Interested In</th>
                                    <th>Deactivate</th>
                                    <th>Created</th>
                                    <th>Action</th>
                                </tr>
                            </tfoot>
                        </table>
                    </div>

                </div>
            </div>
        </div>
    </div>
<?php include("./footer.php"); ?>

        </div>
    </div>



    <!-- Mainly scripts -->
    <script src="js/jquery-2.1.1.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/plugins/metisMenu/jquery.metisMenu.js"></script>
    <script src="js/plugins/slimscroll/jquery.slimscroll.min.js"></script>
    <script src="js/plugins/jeditable/jquery.jeditable.js"></script>

    <!-- Data Tables -->
    <script src="js/plugins/dataTables/jquery.dataTables.js"></script>
    <script src="js/plugins/dataTables/dataTables.bootstrap.js"></script>
    <script src="js/plugins/dataTables/dataTables.responsive.js"></script>
    <script src="js/plugins/dataTables/dataTables.tableTools.min.js"></script>

    <!-- Custom and plugin javascript -->
    <script src="js/inspinia.js"></script>
    <script src="js/plugins/pace/pace.min.js"></script>

    <!-- Page-Level Scripts -->
    <script>
        $(document).ready(function() {
            $('.dataTables-example').dataTable({
                responsive: true,
                "dom": 'T<"clear">lfrtip',
                "tableTools": {
                    "sSwfPath": "js/plugins/dataTables/swf/copy_csv_xls_pdf.swf"
                }
            });
        });

    </script>
<style>
    body.DTTT_Print {
        background: #fff;

    }
    .DTTT_Print #page-wrapper {
        margin: 0;
        background:#fff;
    }

    button.DTTT_button, div.DTTT_button, a.DTTT_button {
        border: 1px solid #e7eaec;
        background: #fff;
        color: #676a6c;
        box-shadow: none;
        padding: 6px 8px;
    }
    button.DTTT_button:hover, div.DTTT_button:hover, a.DTTT_button:hover {
        border: 1px solid #d2d2d2;
        background: #fff;
        color: #676a6c;
        box-shadow: none;
        padding: 6px 8px;
    }

    .dataTables_filter label {
        margin-right: 5px;

    }
</style>
</body>

</html>
