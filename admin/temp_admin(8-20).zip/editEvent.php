<?php
include ("./header.php");
?>
<body>
<link href="css/plugins/blueimp/css/blueimp-gallery.min.css" rel="stylesheet">
<div id="wrapper">
    <?php require_once("./left_navigation.php"); ?>
    <?php
    $eid = 0;
    if(isset($_REQUEST['eid']) && $_REQUEST['eid'] > 0 ){
        $eid = $_REQUEST['eid'];
    }
    $data = getEvent($eid);
    $venues = $data['venues'];
    $categories = $data['categories'];
    $sub_categories = $data['sub_categories'];
    $new_event = $data['new_event'];
    extract($new_event);
    ?>
    <script src="js/jquery-10.1.1.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script type="text/javascript" src='http://maps.google.com/maps/api/js?sensor=false&libraries=places'></script>
    <script src="js/locationpicker.jquery.min.js"></script>

    <link rel="stylesheet" type="text/css" href="css/plugins/chosen/chosen.css" />

    <script src="js/plugins/timepicker/lib/jquery.timepicker.js"></script>
    <link rel="stylesheet" type="text/css" href="js/plugins/timepicker/lib/jquery.timepicker.css" />

    <script src="js/plugins/timepicker/lib/bootstrap-datepicker.js"></script>
    <link rel="stylesheet" type="text/css" href="js/plugins/timepicker/lib/bootstrap-datepicker.css" />

    <script src="js/plugins/timepicker/lib/pikaday.js"></script>
    <link rel="stylesheet" type="text/css" href="js/plugins/timepicker/lib/pikaday.css" />

    <script src="js/plugins/timepicker/lib/jquery.ptTimeSelect.js"></script>
    <link rel="stylesheet" type="text/css" href="js/plugins/timepicker/lib/jquery.ptTimeSelect.css" />
    <script src="js/plugins/timepicker/dist/datepair.js"></script>
    <script src="js/plugins/timepicker/dist/jquery.datepair.js"></script>

    <div id="page-wrapper" class="gray-bg">
        <?php require_once("./top_navigation.php") ?>
        <div class="wrapper wrapper-content animated fadeInRight">
            <div class="row">
                <div class="col-lg-10">
                    <div class="ibox float-e-margins">
                        <div class="ibox-title">
                            <h4><?php echo $id > 0 ? "Edit" : "New"; ?> Event</h4>
                        </div>
                        <div class="ibox-content">
                            <form method="post" action="./action.php" class="form-horizontal">
                                <div class="form-group">
                                    <label class="col-sm-4 control-label">Venue</label>
                                    <div class="col-sm-6">
                                        <div class="input-group">
                                            <select data-placeholder="Choose a Venue..." name="venue" id="venue" class="chosen-select" style="width: 350px;" tabindex="2">
                                                <option value="0">Choose a Venue</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                <div class="fade_area">
                                    <div class="form-group">
                                        <label class="col-sm-4 control-label">Address</label>
                                        <div class="col-sm-6"><input name="address" type="text" class="form-control" id="us3-address" value="" readonly/></div>
                                    </div>
<!--                                    <div class="form-group">-->
<!--                                        <label class="col-sm-4 control-label">Radius</label>-->
<!--                                        <div class="col-sm-6"><input type="text" class="form-control" id="us3-radius"/></div>-->
<!--                                    </div>-->
                                    <div class="form-group">
                                        <div class="col-sm-4"></div>
                                        <div class="col-sm-6">
<!--                                            <div id="us3" style="width: 500px; height: 400px;"></div>-->
<!--                                            <div class="clearfix">&nbsp;</div>-->
<!--                                            <div class="clearfix"></div>-->
                                            <div class="m-t-small" style="width: 100%;">
                                                <label class="p-r-small col-sm-1 control-label">Lat.:</label>
                                                <div class="col-sm-4"><input name="latitude" type="text" class="form-control" style="width: 150px" id="us3-lat" value="" readonly/></div>
                                                <label class="p-r-small col-sm-1 control-label">Long.:</label>
                                                <div class="col-sm-4"><input name="longitude" type="text" class="form-control" style="width: 150px" id="us3-lon" value="" readonly/></div>
                                            </div>
                                            <script>
//                                                var lat = 0;
//                                                var long = 0;
//
//                                                $('#us3').locationpicker({
//                                                    location: {latitude: lat, longitude: long},
//                                                    radius: 300,
//                                                    inputBinding: {
//                                                        latitudeInput: $('#us3-lat'),
//                                                        longitudeInput: $('#us3-lon'),
//                                                        radiusInput: $('#us3-radius'),
//                                                        locationNameInput: $('#us3-address')
//                                                    },
//                                                    enableAutocomplete: true,
//                                                    onchanged: function (currentLocation, radius, isMarkerDropped) {
//                                                        //alert("Location changed. New location (" + currentLocation.latitude + ", " + currentLocation.longitude + ")");
//                                                    }
//                                                });
                                            </script>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="col-sm-4 control-label">Category</label>
                                    <div class="col-sm-6">
                                        <select name="category" id="category" class="form-control m-b">
                                            <?php
                                                foreach($categories as $row){
                                                    if( $row['id'] == $category){
                                                        echo "<option value='".$row['id']."' selected>".$row['title']."</option>";
                                                    }else{
                                                        echo "<option value='".$row['id']."'>".$row['title']."</option>";
                                                    }
                                                }
                                            ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="col-sm-4 control-label">Sub Category</label>
                                    <div class="col-sm-6">
                                        <select name="sub_category" id="sub_category" class="form-control m-b">
                                        </select>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="col-sm-4 control-label">Event Title</label>
                                    <div class="col-sm-6"><input name="title" id="title" type="text" class="form-control" value="<?php echo $title; ?>" ></div>
                                </div>
                                <div class="form-group">
                                    <label class="col-sm-4 control-label">Description</label>
                                    <div class="col-sm-6"><textarea name="description" class="form-control" rows="5"><?php echo $description; ?></textarea></div>
                                </div>
                                <div class="form-group" id="data_1">
                                    <label class="col-sm-4  control-label">Event Date</label>
                                    <div class="col-sm-6 input-group date">
                                        <section id="examples">
                                            <article>
                                                <div class="demo">
                                                    <p id="basicExample">
                                                        <label class="form-control" style="float:left;width : 20%;border: 1px solid transparent;">start : </label>
                                                            <input name="day_start" type="text" class="form-control date start" style="width: 35%;margin-right: 5%" value="<?php echo $event_start == 0 ? "" : date('d/m/Y',$event_start);?>"/>
                                                            <input name="time_start" type="text" class="form-control time start" style="width: 35%"  value="<?php echo $event_start == 0 ? "" : date('g:ia',$event_start);?>"/>
                                                        <label class="form-control" style="float:left;width : 20%;border: 1px solid transparent;margin-top: 10px;">end : </label>
                                                            <input name="day_end" type="text" class="form-control date end" style="margin-top: 10px;width: 35%;margin-right: 5%"  value="<?php echo $event_end == 0 ? "" : date('d/m/Y',$event_end);?>"/>
                                                            <input name="time_end" type="text" class="form-control time end" style="width: 35%;margin-top: 10px;"  value="<?php echo $event_end == 0 ? "" : date('g:ia',$event_end);?>"/>
                                                    </p>
                                                </div>
                                                <script>
                                                    $('#basicExample .time').timepicker({
                                                        'showDuration': true,
                                                        'timeFormat': 'g:ia'
                                                    });

                                                    $('#basicExample .date').datepicker({
                                                        'format': 'd/m/yyyy',
                                                        'autoclose': true
                                                    });

                                                    var basicExampleEl = document.getElementById('basicExample');
                                                    var datepair = new Datepair(basicExampleEl);
                                                </script>
                                            </article>
                                        </section>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="col-sm-4"></div>
                                    <div class="col-sm-6"><button class="btn btn-primary" id="save" type="reset"><i class="fa fa-check"></i>&nbsp;Save</button></div>
                                </div>
                                <input type="hidden" name="eid" value="<?php echo $id; ?>" />
                                <input type="hidden" name="key" value="editEvent" />
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php include("./footer.php"); ?>

    </div>
</div>

<!-- Mainly scripts -->

<script src="js/plugins/metisMenu/jquery.metisMenu.js"></script>
<script src="js/plugins/slimscroll/jquery.slimscroll.min.js"></script>

<!-- Custom and plugin javascript -->
<script src="js/inspinia.js"></script>
<script src="js/plugins/pace/pace.min.js"></script>
<script src="js/plugins/datapicker/bootstrap-datepicker.js"></script>
<script src="js/plugins/chosen/chosen.jquery.js"></script>

<!-- blueimp gallery -->
<script src="js/plugins/blueimp/jquery.blueimp-gallery.min.js"></script>
<script>
    var arr = '<?php echo $sub_categories; ?>';
    var sub_categories = JSON.parse(arr);
    var parent_id = $("#category").val();
    var html = "";
    for(var n = 0; n < sub_categories.length; n ++){
        if(parent_id == sub_categories[n].category_id){
            html += '<option value="'+ sub_categories[n].id +'">'+sub_categories[n].sub_title+'</option>';
        }
    }
    $("#sub_category").html(html);
    var arr_venue = '<?php echo $venues; ?>';
    var venues = JSON.parse(arr_venue);
    var venue_id = <?php echo $venue_id; ?>;
    var html_venue = "";
    for(var k = 0; k < venues.length; k ++){
        if(venue_id == venues[k].id){
            html_venue += '<option value="'+ venues[k].id +'" selected>'+venues[k].club+'</option>';
        }else{
            html_venue += '<option value="'+ venues[k].id +'">'+venues[k].club+'</option>';
        }
    }
    $("#venue").append(html_venue);

    function initGPS(){
        console.log("here");
        $('#us3').locationpicker({
            location: {latitude: lat, longitude: long},
            radius: 300,
            inputBinding: {
                latitudeInput: $('#us3-lat'),
                longitudeInput: $('#us3-lon'),
                radiusInput: $('#us3-radius'),
                locationNameInput: $('#us3-address')
            },
            enableAutocomplete: true,
            onchanged: function (currentLocation, radius, isMarkerDropped) {
                //alert("Location changed. New location (" + currentLocation.latitude + ", " + currentLocation.longitude + ")");
            }
        });
    }
    $(document).ready(function(){
        var sel_venue = $("#venue").val();
        if(sel_venue == 0){
            $(".fade_area").css('display','none');
        }
        var venue_id = $("#venue").val();
        for(var k = 0; k < venues.length; k ++){
            if(venues[k].id == venue_id){
                $(".fade_area").css('display','block');
                $("#us3-address").val(venues[k].address);
                $("#us3-lat").val(venues[k].latitude);
                $("#us3-lon").val(venues[k].longitude);
            }
        }
        var config = {
            '.chosen-select'           : {},
            '.chosen-select-deselect'  : {allow_single_deselect:true},
            '.chosen-select-no-single' : {disable_search_threshold:10},
            '.chosen-select-no-results': {no_results_text:'Oops, nothing found!'},
            '.chosen-select-width'     : {width:"95%"}
        }
        for (var selector in config) {
            $(selector).chosen(config[selector]);
        }
        $('#data_1 .input-group.date').datepicker({
            todayBtn: "linked",
            keyboardNavigation: false,
            forceParse: false,
            calendarWeeks: true,
            autoclose: true
        });
        $("#category").change(function(){
            var parent_id = $("#category").val();
            var html = "";
            for(var n = 0; n < sub_categories.length; n ++){
                if(parent_id == sub_categories[n].category_id){
                    html += '<option value="'+ sub_categories[n].id +'">'+sub_categories[n].sub_title+'</option>';
                }
            }
            $("#sub_category").html(html);
        });

        $("#venue").change(function(){
            var venue_id = $("#venue").val();
            for(var k = 0; k < venues.length; k ++){
                if(venues[k].id == venue_id){
                    $(".fade_area").css('display','block');
                    $("#us3-address").val(venues[k].address);
                    $("#us3-lat").val(venues[k].latitude);
                    $("#us3-lon").val(venues[k].longitude);
//                    $('#us3').trigger("change",initGPS);
//                    $('#us3').on("change",initGPS);
//                    $('#us3').on("onchange",initGPS);
                }
            }
        });
        $("#save").click(function(){
            var parent_id = $("#category").val();
            var venue_id = $("#venue").val();
            if(parent_id == 0){
                alert("Please select category");
                $("#category").focus();
                return ;
            }else if(venue_id == 0){
                alert("Please select venue");
                $("#venue").focus();
                return ;
            }else if($("#title").val() == ""){
                alert("Please input event title");
                $("#title").focus();
                return ;
            }else{
                $("form").submit();
            }
        });
    });
    $(window).load(function(){

    });
</script>
</body>

</html>
