<?php
include ("./header.php");
?>
<body>
<link href='css/fullcalendar.css' rel='stylesheet' />
<link href='css/fullcalendar.print.css' rel='stylesheet' media='print' />
<script src='js/plugins/calendar/moment.min.js'></script>
<script src='js/plugins/calendar/jquery.min.js'></script>
<script src='js/plugins/calendar/fullcalendar.min.js'></script>
<link rel="stylesheet" type="text/css" href="css/plugins/chosen/chosen.css" />
<div id="wrapper">
<?php require_once("./left_navigation.php"); ?>

    <div id="page-wrapper" class="gray-bg">
<?php require_once("./top_navigation.php") ?>
    <div class="row wrapper border-bottom white-bg page-heading">

        <div class="col-lg-10">
            <h2 style="font-weight: bold">Calendar</h2>
        </div>
    </div>
        <?php
        $vid = 0;
        if(isset($_REQUEST['vid']) && $_REQUEST['vid'] > 0 ){
            $vid = $_REQUEST['vid'];
        }
        ?>
    <div class="wrapper wrapper-content animated fadeInRight">
        <div class="row">
            <div class="col-lg-8">
                <form>
                <div class="form-group">
                    <label class="col-sm-4 control-label"><h2 style="margin-top: 0px;margin-bottom: 30px;">Venue</h2></label>
                    <div class="col-sm-6">
                        <div class="input-group">
                            <select data-placeholder="Choose a Venue..." name="venue" id="venue" class="chosen-select" style="width: 350px;height: 34px;" tabindex="2">
                                <option value="0">Choose a Venue</option>
                            </select>
                        </div>
                    </div>
                </div>
                </form>
            </div>
            <div class="col-lg-8">
                <div id='calendar'></div>
            </div>
        </div>
    </div>
<?php include("./footer.php"); ?>

        </div>
    </div>
    <!-- Mainly scripts -->
    <script src="js/bootstrap.min.js"></script>
    <script src="js/plugins/metisMenu/jquery.metisMenu.js"></script>
    <script src="js/plugins/slimscroll/jquery.slimscroll.min.js"></script>
    <script src="js/plugins/jeditable/jquery.jeditable.js"></script>
    <!-- Custom and plugin javascript -->
<script src="js/inspinia.js"></script>
<script src="js/plugins/pace/pace.min.js"></script>
<script src="js/plugins/chosen/chosen.jquery.js"></script>

    <script>
        var arr_venue = '<?php echo getVenues(); ?>';
        var venues = JSON.parse(arr_venue);
        var html_venue = "";
        var active_venue = <?php echo $vid; ?>;
        for(var k = 0; k < venues.length; k ++){
            if(active_venue == venues[k].id){
                html_venue += '<option value="'+ venues[k].id +'" selected>'+venues[k].club+'</option>';
            }else{
                html_venue += '<option value="'+ venues[k].id +'">'+venues[k].club+'</option>';
            }
        }
        $("#venue").append(html_venue);
        $(document).ready(function() {
            var venue_id = $("#venue").val();
            $.post(
                "action.php",
                {
                    key : "ajax",
                    venue_id : venue_id
                },
                function(response){
                    var events = response;
                    var now = new Date();
                    var today = now.getFullYear()+"-"+(now.getMonth()+1)+"-"+now.getDate();
                    $('#calendar').fullCalendar({
                        defaultDate: today,
                        editable: true,
                        eventLimit: true, // allow "more" link when too many events
                        events: events
                    });
                },"json"
            );
            $("#venue").change(function(){
                $("#calendar").html("");
                var venue_id = $("#venue").val();
                location.href = "./view_calendar.php?vid="+venue_id;
            });
        });

    </script>
<style>
    body.DTTT_Print {
        background: #fff;

    }
    .DTTT_Print #page-wrapper {
        margin: 0;
        background:#fff;
    }

    button.DTTT_button, div.DTTT_button, a.DTTT_button {
        border: 1px solid #e7eaec;
        background: #fff;
        color: #676a6c;
        box-shadow: none;
        padding: 6px 8px;
    }
    button.DTTT_button:hover, div.DTTT_button:hover, a.DTTT_button:hover {
        border: 1px solid #d2d2d2;
        background: #fff;
        color: #676a6c;
        box-shadow: none;
        padding: 6px 8px;
    }

    .dataTables_filter label {
        margin-right: 5px;

    }
</style>
</body>

</html>
