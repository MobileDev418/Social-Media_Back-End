<nav class="navbar-default navbar-static-side" role="navigation">
    <div class="sidebar-collapse">
        <ul class="nav" id="side-menu">
            <li class="nav-header">
                <div class="dropdown profile-element">
                    <span>
                        <img alt="image" class="img-circle" src="img/avatar.png" />
                    </span>
                    <a data-toggle="dropdown" class="dropdown-toggle" href="#">
                        <span class="clear">
                            <span class="block m-t-xs"> <strong class="font-bold">Nicholas</strong></span>
                            <span class="text-muted text-xs block">Administrator <b class="caret"></b></span>
                        </span>
                    </a>
                    <ul class="dropdown-menu animated fadeInRight m-t-xs">
                        <li><a href="login.html">Logout</a></li>
                    </ul>
                </div>
            </li>
            <li>
                <a href="./index.php"><i class="fa fa-th-large"></i> <span class="nav-label">Dashboard</span></a>
            </li>
            <li>
                <a href="#"><i class="fa fa-user"></i> <span class="nav-label">Users</span><span class="fa arrow"></span></a>
                <ul class="nav nav-second-level collapse">
                    <li><a href="./view_users.php">View</a></li>
                    <li><a href="./view_reports.php">Report</a></li>
                </ul>
            </li>
            <li>
                <a href="#"><i class="fa fa-list-ul"></i> <span class="nav-label">Categories</span><span class="fa arrow"></span></a>
                <ul class="nav nav-second-level collapse">
                    <li><a href="./view_category.php">New Category</a></li>
                    <li><a href="./view_sub_category.php">New Sub Category</a></li>
                    <li><a href="./view_categories.php">View</a></li>
                </ul>
            </li>
            <li>
                <a href="#"><i class="fa fa-calendar"></i> <span class="nav-label">Venues</span><span class="fa arrow"></span></a>
                <ul class="nav nav-second-level collapse">
                    <li><a href="./editVenue.php">New Venue</a></li>
                    <li><a href="./view_venues.php">Venue List</a></li>
                </ul>
            </li>
            <li>
                <a href="#"><i class="fa fa-calendar"></i> <span class="nav-label">Events</span><span class="fa arrow"></span></a>
                <ul class="nav nav-second-level collapse">
                    <li><a href="./editEvent.php">New Event</a></li>
                    <li><a href="./view_events.php">Upcoming</a></li>
                    <li><a href="./view_event_histories.php">History</a></li>
                </ul>
            </li>
            <li>
                <a href="./view_calendar.php"><i class="fa fa-th-large"></i> <span class="nav-label">Calendar</span></a>
            </li>
            <hr style="border: 1px solid #509E95;margin: 0px;">
            <li>
                <a href="#"><i class="fa fa-calendar"></i> <span class="nav-label">Scraping Venues</span><span class="fa arrow"></span></a>
                <ul class="nav nav-second-level collapse">
                    <li><a href="./view_venue_scraping.php">View All</a></li>
                    <li><a href="./view_team.php?category=basketball">College Basketball</a></li>
                    <li><a href="./view_team.php?category=football">College Football</a></li>
                    <li><a href="./view_team.php?category=MLB">Pro MLB</a></li>
                    <li><a href="./view_team.php?category=NFL">Pro NFL</a></li>
                    <li><a href="./view_team.php?category=NBA">Pro NBA</a></li>
                    <li><a href="./view_team.php?category=NHL">Pro NHL</a></li>
                    <li><a href="./view_team.php?category=MLS">Pro MLS</a></li>
<!--                    <li><a href="./view_team.php?category=NASCAR">Pro NASCAR</a></li>-->
<!--                    <li><a href="./view_team.php?category=horse">Pro Horse</a></li>-->
                </ul>
            </li>
            <li>
                <a href="#"><i class="fa fa-repeat"></i> <span class="nav-label">Go Scraping</span><span class="fa arrow"></span></a>
                <ul class="nav nav-second-level collapse">
                    <li><a href="./view_pre_venue.php?category=all">View All</a></li>
                    <li><a href="./view_scraping_event.php?category=basketball">College Basketball</a></li>
                    <li><a href="./view_scraping_event.php?category=football">College Football</a></li>
                    <li><a href="./view_scraping_event.php?category=mlb">Pro MLB</a></li>
                    <li><a href="./view_scraping_event.php?category=nfl">Pro NFL</a></li>
                    <li><a href="./view_scraping_event.php?category=nba">Pro NBA</a></li>
                    <li><a href="./view_scraping_event.php?category=nhl">Pro NHL</a></li>
                    <li><a href="./view_scraping_event.php?category=mls">Pro MLS</a></li>
<!--                    <li><a href="./view_scraping_event.php?category=nascar">Pro NASCAR</a></li>-->
<!--                    <li><a href="./view_scraping_event.php?category=horse">Pro Horse</a></li>-->
                </ul>
            </li>
        </ul>

    </div>
</nav>