<?php
include ("./header.php");
?>
<body>
<link href="css/plugins/blueimp/css/blueimp-gallery.min.css" rel="stylesheet">
<style>
    .t_b{font-weight : bold; }
</style>
<div id="wrapper">
    <?php require_once("./left_navigation.php"); ?>
    <?php
        $feature = dashboardInfo();
    ?>
    <div id="page-wrapper" class="gray-bg">
        <?php require_once("./top_navigation.php") ?>
        <div class="row wrapper border-bottom white-bg page-heading">
            <div class="col-lg-10">
                <h2 style="font-weight: bold">Dashboard</h2>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-12" style="margin-top:30px;">
                <div class="ibox float-e-margins">
                    <div class="ibox-content text-left p-md" style="display: table">
                        <?php
                        if($feature['is_active'] == 0){
                            echo '<h2><span class="text-navy t_b">Active Event</span> : Not Exist.</h2>';
                        }else{ ?>
                            <h2><span class="text-navy t_b">Active Events</span> </h2>
                            <div class="col-lg-12">
                                <div class="ibox float-e-margins">
                                    <div class="ibox-content">
                                        <table class="table">
                                            <thead>
                                            <tr>
                                                <th>Event Title</th>
                                                <th>Category</th>
                                                <th>Description</th>
                                                <th>Address</th>
                                                <th>Expiration Date</th>
                                            </tr>
                                            </thead>
                                            <tbody>
                                            <?php
                                            foreach($feature['active_events'] as $active_event){
                                                echo '<tr>';
                                                echo "<td>".$active_event['title']."</td>";
                                                echo "<td>".$active_event['category_title']." / ".$active_event['sub_title']."</td>";
                                                echo "<td>".$active_event['description']."</td>";
                                                echo "<td>".$active_event['address']."</td>";
                                                echo "<td>".date('d-m-Y h:i:A',$active_event['event_start'])." ~ ".date('d-m-Y h:i:A',$active_event['event_end'])."</td>";
                                                echo '</tr>';
                                            }
                                            ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        <?php } ?>
                    </div>
                </div>
            </div>
            <div class="col-lg-4">
                <div class="ibox float-e-margins">
                    <div class="ibox-title">
                        <a href="./view_users.php"><span class="label label-success pull-right">View</span></a>
                        <h5>People</h5>
                    </div>
                    <div class="ibox-content text-center">
                        <h1 class="no-margins t_b"><?php echo $feature['count_users']?></h1>
                        <small>Total users</small>
                    </div>
                </div>
            </div>
            <div class="col-lg-4">
                <div class="ibox float-e-margins">
                    <div class="ibox-title">
                        <a href="./view_events.php"><span class="label label-info pull-right">View</span></a>
                        <h5>Event</h5>
                    </div>
                    <div class="ibox-content text-center">
                        <h1 class="no-margins t_b"><?php echo $feature['count_events']?></h1>
                        <small>Total Events</small>
                    </div>
                </div>
            </div>
            <div class="col-lg-4">
                <div class="ibox float-e-margins">
                    <div class="ibox-title">
                        <a href="./view_events.php"> <span class="label label-danger pull-right">View</span></a>
                        <h5>Upcoming</h5>
                    </div>
                    <div class="ibox-content text-center">
                        <h1 class="no-margins t_b"><?php echo $feature['count_upcoming_events']?></h1>
                        <small>Total Upcoming Event</small>
                    </div>
                </div>
            </div>
        </div>
        <div class="wrapper wrapper-content animated fadeInRight">
            <div class="row" style="margin-bottom: 150px;">
                <?php
                $users = adminGetLastUsers();
                $events = adminGetLastEvents();
                ?>
                <div class="col-lg-5">
                    <div class="ibox float-e-margins">
                        <div class="ibox-title">
                            <h4>New Users</h4>
                        </div>
                        <div class="ibox-content">
                            <table class="table">
                                <thead>
                                <tr>
                                    <th>Photo</th>
                                    <th>Username</th>
                                    <th>Email</th>
                                    <th>Created</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php
                                foreach($users as $user){
                                    extract($user);
                                    echo '<tr>';
                                    echo '<td><a href="./editUser.php?key=edit&uid='.$id.'">
                                            <img src="../images/photo/'.$photo_url.'" style="width:35px;height:35px;border-radius: 50%;">
                                            </a></td>';
                                    echo "<td>$username</td>";
                                    echo "<td>$email</td>";
                                    echo "<td>".date('d-M-Y h:i:A',$created)."</td>";
                                    echo '</tr>';
                                }
                                ?>

                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <div class="col-lg-5">
                    <div class="ibox float-e-margins">
                        <div class="ibox-title">
                            <h4>Upcoming Events</h4>
                        </div>
                        <div class="ibox-content">
                            <table class="table">
                                <thead>
                                <tr>
                                    <th>Category</th>
                                    <th>Event</th>
                                    <th>Event Date</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php
                                foreach($events as $event){
                                    echo '<tr>';
                                    echo "<td>".$event['category_title']." / ".$event['sub_title']."</td>";
                                    echo "<td>".$event['title']."</td>";
                                    echo "<td>".date('d-m-Y h:i:A',$event['event_start'])." ~ ".date('d-m-Y h:i:A',$event['event_end'])."</td>";
                                    echo '</tr>';
                                }
                                ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php include("./footer.php"); ?>

    </div>
</div>



<!-- Mainly scripts -->
<script src="js/jquery-2.1.1.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/plugins/metisMenu/jquery.metisMenu.js"></script>
<script src="js/plugins/slimscroll/jquery.slimscroll.min.js"></script>

<!-- Custom and plugin javascript -->
<script src="js/inspinia.js"></script>
<script src="js/plugins/pace/pace.min.js"></script>

<!-- blueimp gallery -->
<script src="js/plugins/blueimp/jquery.blueimp-gallery.min.js"></script>
<script>
    $(document).ready(function(){
        $(".gallery_photo").mouseover(function(){
            var id = $(this).attr("id");
            var new_id = id.replace("photo_","");
            $("#close_"+new_id).fadeIn();
        });
        $(".gallery_photo").mouseout(function(){
            var id = $(this).attr("id");
            var new_id = id.replace("photo_","");
            $("#close_"+new_id).fadeOut();
        });

    });
</script>
</body>

</html>
