<?php
    require_once("./function.php");
?>
<!DOCTYPE html>
<html>

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title><?php echo ADMIN_TITLE;?></title>

    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="font-awesome/css/font-awesome.css" rel="stylesheet">

    <!-- Data Tables -->
    <link href="css/plugins/dataTables/dataTables.bootstrap.css" rel="stylesheet">
    <link href="css/plugins/dataTables/dataTables.responsive.css" rel="stylesheet">
    <link href="css/plugins/dataTables/dataTables.tableTools.min.css" rel="stylesheet">

    <link href="css/plugins/iCheck/custom.css" rel="stylesheet">
    <link href="css/animate.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
</head>
<body>
<div id="wrapper">
<?php require_once("./left_navigation.php"); ?>
    <div id="page-wrapper" class="gray-bg">
<?php require_once("./top_navigation.php") ?>
<?php
    $category = "";
    if(isset($_REQUEST['category']) && $_REQUEST['category'] != "" ){
        $category = $_REQUEST['category'];
    }

?>
    <div class="row wrapper border-bottom white-bg page-heading">
        <div class="col-lg-10">
            <h2 style="font-weight: bold">category - <?php echo ucfirst($category); ?></h2>
        </div>
    </div>
        <style>
            table thead tr th{text-align: center;}
        </style>
    <div class="wrapper wrapper-content animated fadeInRight">
        <div class="row">
            <div class="col-lg-12">
                <div class="ibox float-e-margins">
                    <div class="ibox-content">
                        <table class="table table-striped table-bordered table-hover" >
                            <thead>
                            <tr>
                                <th>No</th>
                                <th>Team name</th>
                                <th>key1</th>
                                <th>key2</th>
                                <th>url</th>
                            </tr>
                            </thead>
                            <tbody class="result"  style="height:600px; overflow:auto;">

                            </tbody>
                        </table>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php include("./footer.php"); ?>

        </div>
    </div>

    <!-- Mainly scripts -->
    <script src="js/jquery-2.1.1.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/plugins/metisMenu/jquery.metisMenu.js"></script>
    <script src="js/plugins/slimscroll/jquery.slimscroll.min.js"></script>
    <script src="js/plugins/jeditable/jquery.jeditable.js"></script>

<!-- Data Tables -->
<script src="js/plugins/dataTables/jquery.dataTables.js"></script>
<script src="js/plugins/dataTables/dataTables.bootstrap.js"></script>
<script src="js/plugins/dataTables/dataTables.responsive.js"></script>
<script src="js/plugins/dataTables/dataTables.tableTools.min.js"></script>
    <!-- Custom and plugin javascript -->
    <script src="js/inspinia.js"></script>
    <script src="js/plugins/pace/pace.min.js"></script>

    <!-- Page-Level Scripts -->
    <script>
        var category = "<?php echo $category; ?>";
        $(document).ready(function() {
            $.post(
                "./parse.php",
                {
                    key : category,
                    target : "team"
                },
                function(response){
                    console.log(response);
                    var html = "";
                    if(response.length > 0 ){

                        for(var i = 0; i < response.length; i ++){
                            html += "<tr>";
                            html += "<td>"+(parseInt(i)+1)+"</td>";
                            html += "<td>"+response[i].name+"</td>";
                            html += "<td>"+response[i].key1+"</td>";
                            html += "<td>"+response[i].key2+"</td>";
                            html += "<td>"+response[i].url+"</td>";
                            html += "</tr>";
                        }
                        $(".result").append(html);
                    }

                },"json"
            );
        });

    </script>
<style>
    body.DTTT_Print {
        background: #fff;
    }
    .DTTT_Print #page-wrapper {
        margin: 0;
        background:#fff;
    }
    button.DTTT_button, div.DTTT_button, a.DTTT_button {
        border: 1px solid #e7eaec;
        background: #fff;
        color: #676a6c;
        box-shadow: none;
        padding: 6px 8px;
    }
    button.DTTT_button:hover, div.DTTT_button:hover, a.DTTT_button:hover {
        border: 1px solid #d2d2d2;
        background: #fff;
        color: #676a6c;
        box-shadow: none;
        padding: 6px 8px;
    }

    .dataTables_filter label {
        margin-right: 5px;
    }
</style>
</body>

</html>
