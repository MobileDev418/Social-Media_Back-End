<?php
    require_once "./function.php";

$param = $_REQUEST;

$response = array();
if(!isset($param['key'])){
    redirect_url("./index.php");
}

//print_r($param);exit;
switch($param['key']){
    case "register":
        register($param['username'], $param['password'], $param['email']);
        break;
    case "login":
        login($param['username'], $param['password']);
        break;
    case "user":
        saveUser();
        break;
    case "editProfile":
        editProfile();
        break;
    case "editCategory":
        $id = $param['cid'];
        $title = $param['title'];
        editCategory($id, $title);
        break;
    case "editSubCategory":
        $id = $param['cid'];
        $category_id = $param['category_id'];
        $sub_title = $param['sub_title'];
        editSubCategory($id,$category_id, $sub_title);
        break;
    case "editEvent":
        $id = $param['eid'];
        $category = $param['category'];
        $sub_category = $param['sub_category'];
        $title = $param['title'];
        $description = $param['description'];
        $event_start = date_create_from_format('d/m/Y g:ia',$param['day_start']."".$param['time_start']);
        $event_end = date_create_from_format('d/m/Y g:ia',$param['day_end']."".$param['time_end']);
        $venue_id = $param['venue'];
        editEvent($id,$category, $sub_category, $title, $description, $event_start->getTimestamp(), $event_end->getTimestamp(), $venue_id);
        break;
    case "editVenue":
        $new_venue = array("id"=>0,"club"=>"","address"=>"","stadium"=>"","longitude"=>0,"latitude"=>0);
        $new_venue['id'] = $param['vid'];
        $new_venue['club'] = $param['club'];
        $new_venue['address'] = $param['address'];
        $new_venue['stadium'] = $param['stadium'];
        $new_venue['longitude'] = $param['longitude'];
        $new_venue['latitude'] = $param['latitude'];
        editVenue($new_venue);
        break;
    case "changePassword":
        changePassword();
        break;
    case "delUser":
        deleteUser($param['uid']);
        break;
    case "susUser":
        suspendUser($param['uid']);
        break;
    case "delCategory":
        deleteCategory($param['cid']);
        break;
    case "delSubCategory":
        deleteSubCategory($param['cid']);
        break;
    case "delEvent":
        deleteEvent($param['eid']);
        break;
    case "delVenue":
        deleteVenue($param['vid']);
        break;
    case "delPhoto":
        deletePhoto($param['uid'],$param['pid']);
        break;
    case "delReport":
        deleteReport($param['rid']);
        break;
    case "keepReport":
        keepReport($param['rid']);
        break;
    case "ajax":
        $response = json_encode(adminCalendarEvents($param['venue_id']));
        break;
    default:
        redirect_url("./index.php");
}

echo $response;
exit;
?>