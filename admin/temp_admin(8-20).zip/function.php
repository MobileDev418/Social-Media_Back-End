<?php
    require_once("../api/Database.php");
    define('SAVE_PHOTO', './images/photos/');  // save image path
    define('DELETE_PHOTO', './images/photos/');  // delete image path

    define('SAVE_USER_PHOTO', './images/user/');  // save user image path
    define('DELETE_USER_PHOTO', './images/user/');  // delete user image path

    $GENDER = array("1"=>"Male", "2"=>"Female");
    $permission = array("0"=>"default", "1"=>"admin");

    $db = new Database();

    function redirect_url( $url = './index.php' ){
        echo '<script>location.href = "'.$url.'"; </script>';exit;
    }

    function generate_token($length = 8) {
        $chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz1234567890";
        //length:36
        $final_rand = '';
        for ($i = 0; $i < $length; $i++) {
            $final_rand .= $chars[rand(0, strlen($chars) - 1)];
        }
        return $final_rand;
    }

    function qa_email_validate($email)
    {
        return preg_match("/^[\-\!\#\$\%\&\'\*\+\/\=\?\_\`\{\|\}\~a-zA-Z0-9\.\^]+\@[a-zA-Z0-9\-]+\.[a-zA-Z0-9\.\-]+$/", $email) === 1;
    }
    function pastTime($seconds)
    {
    //    echo $seconds;exit;
        $seconds=max($seconds, 1);
        $scales=array(
            31557600 => array( '1year'   , 'years'   ),
            2629800 => array( '1month'  , 'months'  ),
            604800 => array( '1week'   , 'weeks'   ),
            86400 => array( '1day'    , 'days'    ),
            3600 => array( '1hour'   , 'hours'   ),
            60 => array( '1minute' , 'minutes' ),
            1 => array( '1second' , 'seconds' ),
        );
        $string = "";
        foreach ($scales as $scale => $phrases)
            if ($seconds>=$scale) {
                $count=floor($seconds/$scale);

                if ($count==1)
                    $string .= $phrases[0];
                else
                    $string .= $count . $phrases[1];
                break;
            }
        return $string;
    }
    function check_user(){
        global $db;
        if( isset($_SESSION['log_in']) && $_SESSION['log_in'] ){
            return true;
        }else{
            redirect_url('./login.php');
        }
    }
    function login($username, $password){

        if($username == "" || $password == "" ){
            redirect_url("./login.php?err=error1");
        }
        global $db;
        $info = $db -> single("select * from admin where username= '$username' and password='". md5($password) ."'");

        if (count($info) == 0) {
            redirect_url("./login.php?err=error1");
        }else {
            /* session register */
            $_SESSION['user_id'] = $info['id'];
            $_SESSION['username'] = $info['username'];
            $_SESSION['photo'] = "admin.png";
            $_SESSION['log_in'] = true;
            $_SESSION['admin'] = $info['permission'];
            redirect_url("./index.php");
        }
    }
    function forgotPassword(){

        global $db;
        $email = $_REQUEST['email'];
        $info = $db -> single("SELECT email FROM account WHERE email = '$email' ");
        $to = $info['email'];
        $newpass = rand(100000, 999999);
        $db -> execute("update account set password = '".md5($newpass)."' where email = '$to'");
        $subject = "Change Password";
        $txt = "Your password changed. New password : ".$newpass. "\r\n" ;

        try {
            $headers = 'From: admin@indyhost.com' . "\r\n" .
                'Reply-To: admin@indyhost.com' . "\r\n" .
                'X-Mailer: PHP/' . phpversion();

            mail($to, $subject, $txt, $headers);
        }
        catch (Exception $e)
        {
            redirect_url('./signup.php');
        }
        redirect_url('./login.php');

    }
    function register($username, $password, $email){
        if($username == "" || $email == "" || (!qa_email_validate($email)) || $password == "" ){
            redirect_url("./login.php?err3");
        }
        global $db;
        $check = $db -> single("select count(*) as count from account where username= '$username' and email='$email'");
        if ($check["count"] > 0) {
            redirect_url("./login.php?err4");
        } else {
            // add new user
            if(!$db -> execute("insert into account values(null,'$username','$username', '$email', 'avatar.png', '".md5($password)."','0')")){
                redirect_url("./login.php?err2");
            }
            redirect_url("./login.php");
        }
    }
    /* admin */
    /* user */
    function getUser($user_id){
        global $db;
        $new_user = array("id"=>0,"firstname"=>"","lastname"=>"","username"=>"","email"=>"","gender"=>"","birthday"=>"","created"=>"", "photo_url"=>"");
        if($user_id > 0){
            $sql = "SELECT a.* ,b.photo_url
                    FROM account a
                    LEFT JOIN (SELECT account_id, photo_url FROM account_photos GROUP BY account_id) b ON a.id = b.account_id where a.id = $user_id";
            $new_user = $db -> single($sql);
        }
        return $new_user;
    }
    function dashboardInfo(){
        global $db;
        $result = array();
        $now = time();
        $chk_event = $db -> single("SELECT COUNT(*) as chk FROM vanity_events WHERE active = 1");
        $active_events = array();
        if($chk_event['chk'] != 0){
            $active_events = $db -> result("SELECT a.*, b.title AS category_title, c.sub_title, c.caption, d.club, d.address, d.stadium, d.longitude,d.latitude, '' AS site_url
                    FROM vanity_events a
                    LEFT JOIN categories b ON a.category = b.id
                    LEFT JOIN sub_categories c ON a.sub_category = c.id
                    LEFT JOIN venues d ON a.venue_id = d.id
                    WHERE a.active = 1 ");
        }
        $count_user = $db -> single("select count(*) as ct from account ");
        $count_event = $db -> single("select count(*) as ct from vanity_events ");
        $count_upcoming_event = $db -> single("SELECT COUNT(*) AS ct FROM vanity_events WHERE event_start  > '$now' ");

        $result['is_active'] = $chk_event['chk'];
        $result['active_events'] = $active_events;
        $result['count_users'] = $count_user['ct'];
        $result['count_events'] = $count_event['ct'];
        $result['count_upcoming_events'] = $count_upcoming_event['ct'];
        return $result;
    }
    function adminGetUsers(){
        global $db;
        $sql = "SELECT a.* ,b.photo_url
                FROM account a
                LEFT JOIN (SELECT account_id, photo_url FROM account_photos WHERE is_avatar = 1) b ON a.id = b.account_id";
        $result = $db -> result($sql);
        return $result;
    }
    function adminGetLastUsers(){
        global $db;
        $sql = "SELECT a.* ,b.photo_url
                FROM account a
                LEFT JOIN (SELECT account_id, photo_url FROM account_photos WHERE is_avatar = 1) b ON a.id = b.account_id
                ORDER BY a.created DESC limit 10 ";
        $result = $db -> result($sql);
        return $result;
    }
    function adminGetLastEvents(){
        global $db;
        $now = time();
        $sql = "SELECT a.* , b.title AS category_title, c.sub_title
                FROM vanity_events a
                LEFT JOIN categories b ON a.category = b.id
                LEFT JOIN sub_categories c ON a.sub_category = c.id
                WHERE a.event_start >  '$now' order by a.event_start asc limit 10 ";
        $result = $db -> result($sql);
        return $result;
    }
    function deleteUser($user_id){
        global $db;
        $account_id = $user_id;
        $db -> execute("DELETE FROM account WHERE id = $account_id");
        $db -> execute("DELETE FROM account_photos WHERE account_id = $account_id");
        $db -> execute("DELETE FROM chat WHERE sender_id = $account_id OR receiver_id = $account_id");
        $db -> execute("DELETE FROM device WHERE account_id = $account_id");
        $db -> execute("DELETE FROM kiss WHERE account_id = $account_id OR kissed_id = $account_id");
        $db -> execute("DELETE FROM matchs WHERE account1 = $account_id OR account2 = $account_id");
        $db -> execute("DELETE FROM search_setting WHERE account_id = $account_id");
        $db -> execute("DELETE FROM show_setting WHERE account_id = $account_id");
        $db -> execute("DELETE FROM search_block WHERE user_id = $account_id OR target_id = $account_id");

        redirect_url('./view_users.php');
    }
    function suspendUser($user_id){
        global $db;
        $account_id = $user_id;

        $db -> execute("update account set status = 1 where id = $user_id");

        redirect_url('./view_users.php');
    }
    function adminGetUser(){
        global $db;
        $sql = "SELECT * FROM account WHERE id = ".$_SESSION['user_id'];
        $result = $db -> single($sql);

        return $result;
    }
    function getUserPhotos($user_id){
        global $db;
        if($user_id > 0){
            $sql = "SELECT id, photo_url, is_avatar FROM account_photos WHERE account_id = $user_id";
            $datas = $db -> result($sql);
        }
        return $datas;
    }
    function deletePhoto($uid, $photo_id){
        global $db;
        $db -> execute("delete from account_photos where id = $photo_id ");
        $db -> execute("delete from kiss where photo_id = $photo_id");

        redirect_url('./editUser.php?key=edit&uid=' . $uid);
    }
    function editProfile(){
        global $db;
        $fullname = $db -> _db -> real_escape_string($_POST['fullname']);
        $username = $db -> _db -> real_escape_string($_POST['username']);
        $email = $db -> _db -> real_escape_string($_POST['email']);
        $account_id = $_SESSION['user_id'];

        if($username == "" || $email == ""){
            redirect_url('./profile.php?err=error2');
        }

        if(!$db -> execute("update account set fullname = '$fullname', username = '$username', email = '$email' where id = $account_id ")){
            redirect_url('./profile.php?err=error1');
        }

        if (isset($_FILES['photo'])) { // user photo
            $default = explode(".", $_FILES["photo"]["name"]);
            $extension = end($default);
            $filename = generate_token(16) . "." . $extension;
            if (move_uploaded_file($_FILES["photo"]["tmp_name"], SAVE_USER_PHOTO . $filename)) :
                if(!$db -> execute("update account set photo = '$filename' where id = $account_id")){
                    redirect_url('./profile.php?err=error1');
                }
            endif;
        }
        $_SESSION['username'] = $username;
        $_SESSION['fullname'] = $fullname;
        $_SESSION['email'] = $email;
        $_SESSION['photo'] = $filename;
        redirect_url('./index.php');
    }
    function saveUser(){
        global $db;
        $fullname = $db -> _db -> real_escape_string($_POST['fullname']);
        $username = $db -> _db -> real_escape_string($_POST['username']);
        $email = $db -> _db -> real_escape_string($_POST['email']);
        $is_admin = $db -> _db -> real_escape_string($_POST['is_admin']);
        $new_password = $db -> _db -> real_escape_string($_POST['new_password']);
        $action = $_POST['action'];
        $user_id = $_POST['user_id'];

        $now = time();
        if($action == 'edit'){
            // edit user
            $sql = "";
            if($new_password == "") { $sql = "update account set fullname = '$fullname', username = '$username', email = '$email', is_admin = '$is_admin' where id = $user_id ";}
            else{ $sql = "update account set fullname = '$fullname', username = '$username', email = '$email', is_admin = '$is_admin', password = '".md5($new_password)."' where id = $user_id ";}
            if(!$db -> execute($sql)){
                redirect_url('./admin_editUser.php?err=error2');
            }

            if (isset($_FILES['photo'])) { // photo
                $default = explode(".", $_FILES["photo"]["name"]);
                $extension = end($default);
                $filename = generate_token(16) . "." . $extension;
                if (move_uploaded_file($_FILES["photo"]["tmp_name"], SAVE_USER_PHOTO . $filename)) :
                    if(!$db -> execute("update account set photo = '$filename' where id = $user_id")){
                        redirect_url('./admin_editUser.php?err=error2');
                    }
                endif;
            }
        }
        elseif($action == 'new'){
            // add user
            $sql = "insert into account values( null, '$fullname','$username', '$email','' , '".md5($new_password)."', '$is_admin')";
            if(!$db -> execute( $sql )){
                redirect_url('./admin_editUser.php?err=error1');
            }

            $user_id = $db -> _db -> insert_id;
            if (isset($_FILES['photo'])) { // photo
                $default = explode(".", $_FILES["photo"]["name"]);
                $extension = end($default);
                $filename = generate_token(16) . "." . $extension;
                if (move_uploaded_file($_FILES["photo"]["tmp_name"], SAVE_USER_PHOTO . $filename)) :
                    if(!$db -> execute("update account set photo = '$filename' where id = $user_id")){
                        redirect_url('./admin_editUser.php?err=error1');
                    }
                endif;
            }
        }
        redirect_url('./manage_user.php?uid='.$user_id);
    }
    /*report*/
    function adminGetReports(){
        global $db;
        $sql = "SELECT a.id, a.account_id, b.username, d.photo_url AS avatar, a.photo_id, e.photo_url, c.username AS author, a.created
                FROM reports a
                LEFT JOIN account b ON a.account_id = b.id
                LEFT JOIN account_photos d ON a.account_id = d.account_id AND d.is_avatar = 1
                LEFT JOIN account_photos e ON a.photo_id = e.id
                LEFT JOIN account c ON a.author = c.id ";
        $result = $db -> result($sql);
        return $result;
    }
    function deleteReport($rid){
        global $db;
        $sql = "delete from reports where id = $rid ";
        $db -> execute($sql);
        redirect_url('./view_reports.php');
    }
    function keepReport($rid){
        global $db;
        $sql = "delete from reports where id = $rid ";
        $db -> execute($sql);

        $sql = "delete from account_photos where id = (select photo_id from reports where id = $rid) ";
        $db -> execute($sql);

        redirect_url('./view_reports.php');
    }
    /*event*/
    function adminGetEvents($type){
        global $db;
        $now = time();
        $today = mktime(0,0,0,date("m"), date("d"), date("Y"));
        $tomorrow = mktime(0,0,0,date("m"), date("d") + 1, date("Y"));
        $endSeason = mktime(0,0,0,date("m") + 3, date("d"), date("Y"));
        $endSeasonHistory = mktime(0,0,0,date("m") + 3, date("d"), date("Y"));
        if($type == "today"){
            $sql = "SELECT a.*, b.title AS category_title, c.sub_title, d.club, d.address, d.stadium, d.longitude,d.latitude
                    FROM vanity_events a
                    LEFT JOIN categories b ON a.category = b.id
                    LEFT JOIN sub_categories c ON a.sub_category = c.id
                    left join venues d on a.venue_id = d.id
                    WHERE a.event_start > '$today' AND a.event_start < '$tomorrow' ORDER BY a.event_start ASC";
        }elseif($type == "upcoming"){
            $sql = "SELECT a.*, b.title AS category_title, c.sub_title, d.club, d.address, d.stadium, d.longitude,d.latitude
                    FROM vanity_events a
                    LEFT JOIN categories b ON a.category = b.id
                    LEFT JOIN sub_categories c ON a.sub_category = c.id
                    left join venues d on a.venue_id = d.id
                    WHERE a.event_start > '$now' and a.event_start < '$endSeason' ORDER BY a.event_start ASC";
        }elseif($type == "history"){
            $sql = "SELECT a.*, b.title AS category_title, c.sub_title, d.club, d.address, d.stadium, d.longitude,d.latitude
                    FROM vanity_events a
                    LEFT JOIN categories b ON a.category = b.id
                    LEFT JOIN sub_categories c ON a.sub_category = c.id
                    left join venues d on a.venue_id = d.id
                    WHERE a.event_start < '$now' and a.event_start > '$endSeasonHistory' ORDER BY a.event_start DESC ";
        }
        $result = $db -> result($sql);
        return $result;
    }
    function getEvent($eid){
        global $db;
        $venues = $db -> result("select * from venues order by club  ");
        $categories = $db -> result("select * from categories order by id ");
        $sub_categories = $db -> result("select * from sub_categories order by id ");

        $new_event = array("id"=>0,"category"=>0,"sub_category"=>0,"title"=>"","description"=>"","event_start"=>0,"event_end"=>0,"venue_id"=>0);
        if($eid > 0){
            $sql = "select * from vanity_events where id = $eid ";
            $new_event = $db -> single($sql);
        }
        return array("venues"=>json_encode($venues), "categories"=>$categories,"sub_categories"=>json_encode($sub_categories), "new_event"=>$new_event);
    }
    function editEvent($id,$category, $sub_category, $title, $description, $event_start, $event_end, $venue_id){
        global $db;
        $sql = "";
        $now = time();
        if($id > 0){//update
            $sql = "update vanity_events set category=$category, sub_category = $sub_category, title = '$title', description = '$description', venue_id = $venue_id, event_start='$event_start',event_end='$event_end' where id = $id ";
        }else{
            $sql = "insert into vanity_events(category, sub_category, title, description, venue_id, event_start, event_end, created)
                    values($category, $sub_category, '$title', '$description', $venue_id, '$event_start', '$event_end', $now ); ";
        }
        $db->execute($sql);
        redirect_url('./view_events.php');
    }
    function deleteEvent($eid){
        global $db;
        $sql = "delete from vanity_events where id = $eid ";
        $db->execute($sql);
        redirect_url("./view_events.php");
    }
    function getVenues(){
        global $db;
        $venues = $db -> result("select * from venues order by club  ");
        return json_encode($venues);
    }
    function adminCalendarEvents($vid){
        global $db;
        $now = time();
        $add_query = "";
        if($vid > 0){
            $add_query = "where venue_id = $vid";
        }else{
            $add_query = "where venue_id = 1";
        }
        $sql = "SELECT id, title, event_start, event_end, active FROM vanity_events $add_query ";
        $result = $db -> result($sql);
        $new_events = array();
        foreach($result as $event){
            $temp = array();
            $temp['title'] = strlen($event['title']) > 20 ? substr($event['title'],0,30)."..." : $event['title'];
            $temp['start'] = date('Y-m-d',$event['event_start'])."T".date('H:i:s',$event['event_start']);//2015-02-03T13:00:00
            $temp['end'] = date('Y-m-d',$event['event_end'])."T".date('H:i:s',$event['event_end']);//2015-02-03T13:00:00
            if($now > $event['event_end']){
                $temp['color'] = '#666666';
            }else{
                $temp['url'] = "./editEvent.php?key=edit&eid=".$event['id'];
            }

            if($event['active'] == 1) $temp['color'] = '#AC68EB';
            $new_events[] = $temp;
        }
        return $new_events;
    }
    /* venue */
    function getVenue($vid){
        global $db;
        $new_venue = array("id"=>0,"club"=>"","address"=>"","stadium"=>"","longitude"=>0,"latitude"=>0);
        if($vid > 0){
            $sql = "select * from venues where id = $vid ";
            $new_venue = $db -> single($sql);
        }
        return $new_venue;
    }
    function editVenue($venue){
        global $db;
        extract($venue);
        $sql = "";
        $address = $db->_db->real_escape_string($address);
        $stadium = $db->_db->real_escape_string($stadium);

        if($id > 0){//update
            $sql = "update venues set club='$club', address= '$address', stadium= '$stadium', longitude=$longitude, latitude=$latitude where id = $id ";
        }else{
            $key1 = generate_token(4);
            $key2 = generate_token(4);
            $sql = "insert into venues(club, address, stadium, longitude, latitude, subject, key1, key2)
                    values('$club', '$address', '$stadium', $longitude, $latitude , 'manual', '$key1', '$key2'); ";
        }
        $db->execute($sql);
        redirect_url('./view_venues.php');
    }
    function adminGetVenues(){
        global $db;
        $sql = "select * from venues order by club ";
        $result = $db -> result($sql);
        return $result;
    }
    function deleteVenue($vid){
        global $db;
        $sql = "delete from venues where id = $vid ";
        $db->execute($sql);
        redirect_url("./view_venues.php");
    }
    /* category */
    function adminGetCategory(){
        global $db;
        $sql = "SELECT * FROM categories";
        $result = $db -> result($sql);
        return $result;
    }
    function getCategory($cid){
        global $db;
        $new_user = array("id"=>0,"title"=>"");
        if($cid > 0){
            $sql = "SELECT *
                    FROM categories
                    WHERE id = $cid";
            $new_user = $db -> single($sql);
        }
        return $new_user;
    }
    function deleteCategory($cid){
        global $db;
        $sql = "delete from sub_categories where category_id = $cid ";
        $db->execute($sql);
        $sql = "delete from categories where id = $cid ";
        $db->execute($sql);
        redirect_url("./view_category.php");
    }
    function editCategory($cid, $title){
        global $db;
        $sql = "";
        if($cid > 0){//update
            $sql = "update categories set title = '$title' where id = $cid ";
        }else{
            $sql = "insert into categories(title) values('$title'); ";
        }
        $db->execute($sql);
        redirect_url('./view_category.php');
    }
    function adminGetSubCategory(){
        global $db;
        $sql = "SELECT a.*, b.title
                FROM sub_categories a
                LEFT JOIN categories b ON a.category_id = b.id
                ORDER BY a.category_id ASC";
        $result = $db -> result($sql);
        return $result;
    }
    function editSubCategory($cid,$category_id, $sub_title){
        global $db;
        $sql = "";
        $newid = 0;
        if($cid > 0){//update
            $newid = $cid;
            $sql = "update sub_categories set category_id = $category_id, sub_title = '$sub_title' where id = $cid ";
            $db->execute($sql);
        }else{
            $sql = "insert into sub_categories(category_id, sub_title) values('$category_id','$sub_title'); ";
            $db->execute($sql);
            $newid = $db->_db->insert_id;
        }

        if (isset($_FILES['caption'])) {
            $default = explode(".", $_FILES["caption"]["name"]);
            $extension = end($default);
            $filename = $_FILES["caption"]["name"] . "." . $extension;
            //echo SAVE_PHOTO . $filename;exit;
            $now = time();
            if (move_uploaded_file($_FILES["caption"]["tmp_name"], '../images/event/' . $filename)) {
                $db->execute("update sub_categories set caption = '$filename' where id = $newid ");
            }
        }
        redirect_url('./view_sub_category.php');
    }
    function getSubCategory($cid){
        global $db;
        $categories = $db -> result("select * from categories order by id ");
        $new_sub_category = array("id"=>0,"category_id"=>"","sub_title"=>"","caption"=>"");
        if($cid > 0){
            $sql = "SELECT *
                    FROM sub_categories
                    WHERE id = $cid";
            $new_sub_category = $db -> single($sql);
        }
        return array("categories"=>$categories, "new_sub_category"=>$new_sub_category);
    }
    function deleteSubCategory($cid){
        global $db;
        $sql = "delete from sub_categories where id = $cid ";
        $db->execute($sql);
        redirect_url("./view_sub_category.php");
    }
    function adminGetVenuesScraping(){
        global $db;
        $subjects = array("mlb","nfl","nba","nhl","mls","nascar","horse","basketball","football");
        foreach($subjects as $arr){
            $temp = $db -> result("select * from team_".$arr);
            foreach($temp as $row){
                extract($row);
                $chk = $db->single("select count(*) as chk from venues where key2 = '$key2' and subject = '$subject' ");
                if($chk['chk'] > 0){
                    $db->execute("update venues set club = '$team_name',key1='$key1',photo='$photo' where key2 = '$key2' and subject = '$subject' ");
                }else{
                    $db->execute("insert into venues(club,address,stadium,longitude,latitude,key1,key2,photo,subject)
                                values('$team_name','$address','$stadium','$longitude','$latitude','$key1','$key2','$photo','$subject')");
                }
            }
        }

        $sql = "select * from venues where key2 <> '' and subject <> '' order by club  ";
        $result = $db -> result($sql);
        return $result;
    }
    function adminGetScrapingVenue($category){
        global $db;
        $sql = "";
        if($category == "all" ){
            $sql = "select * from venues where key2 <> '' and subject <> '' limit 3";
        }else{
            $sql = "select * from venues where key2 <> '' and subject <> '' and subject = '$category' limit 0, 400 ";
        }

        $result = $db->result($sql);
        return json_encode($result);
    }
    function adminGetPreVenues($category){
        global $db;
        $sql = "";
        $add_query = "";
        if($category == "all"){
            $add_query = " 1 ";
        }else{
            $add_query = "subject = '$category'";
        }
        if($category == "all" ){
            $sql = "select * from pre_events where $add_query order by subject, id ";
        }else{
            $sql = "select * from venues where key2 <> '' and subject <> '' and subject = '$category' limit 0, 400 ";
        }

        $result = $db->result($sql);
        return $result;
    }
    ?>